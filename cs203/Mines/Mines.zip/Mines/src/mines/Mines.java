/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mines;

import javalib.colors.White;
import javalib.impworld.World;
import javalib.worldimages.Posn;
import javalib.worldimages.RectangleImage;
import javalib.worldimages.WorldImage;

/**
 *
 * @author maxmorris
 */
public class Mines extends World {

    //Class constants
    public static int MAX_COLS=20;
    public static int MAX_ROWS=20;
    public static int MAX_MINES=MAX_COLS*MAX_ROWS
    
    //Class fields
    int width =MAX_COLS*Space.SIZE;
    int height = MAX_ROWS*Space.SIZE;
    
    Spaces board = new Spaces(MAX_COLS, MAX_ROWS);
    WorldImage background =
            new RectangleImage(new Posn(this.width/2, this.height/2),
                                this.width, this.height, new White());
    
    public Mines() {
        super();
        width =MAX_COLS*Space.SIZE;
        height = MAX_ROWS*Space.SIZE;
    }
    
    public void layBombs () {
        int[] intArray = new int[MAX_COLS];
        for (int i=0; i<MAX_COLS; i++) {
            intArray[i]=MAX_ROWS;
        }return intArray;
    }
    
    public static Examples examplesInstance = new Examples();
}
