/*
 * CS203
 * Spring 2013
 * Max Morris
 * <Assignment>
 */

package mines;

import java.util.ArrayList;
import java.util.List;
import javalib.worldimages.OverlayImages;
import javalib.worldimages.WorldImage;

public class Spaces {
    
    Space[][] spaces;
    
    public Spaces(int x, int y) {
        this.spaces = new Space[x][y];
    }
    
    public WorldImage blocksImage(WorldImage background) {
        for (int i=0; i<spaces[0].length; i++) {
            for (int j=0; j<spaces.length; i++) {
            background = new OverlayImages(background, spaces[j][i].spaceImage());
            }
        }
        return background;
    }

}
